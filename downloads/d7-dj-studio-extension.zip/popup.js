document.getElementById('local').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'open', live: false });
  window.close();
});
document.getElementById('live').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'open', live: true });
  window.close();
});
