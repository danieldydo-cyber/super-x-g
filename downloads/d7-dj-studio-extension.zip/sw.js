chrome.action.onClicked.addListener(() => {
  openStudio(false);
});
function openStudio(live) {
  const url = live
    ? 'https://danieldydo-cyber.github.io/super-x-g/dloop.html'
    : chrome.runtime.getURL('app/shell.html');
  chrome.windows.create({ url, type: 'normal', width: 1500, height: 940 });
}
chrome.runtime.onMessage.addListener((msg, _s, send) => {
  if (msg && msg.type === 'open') { openStudio(!!msg.live); send({ ok: true }); }
});
