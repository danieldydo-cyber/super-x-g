Super DJ Loops — rozszerzenie Chrome (Manifest V3)
1. Rozpakuj zip.
2. Chrome -> chrome://extensions -> włącz "Tryb dewelopera".
3. "Załaduj rozpakowane" -> wskaż folder z manifest.json.
4. Kliknij ikonę rozszerzenia — otworzy się aplikacja (działa offline).
Wersja online: https://danieldydo-cyber.github.io/super-x-g/superdj.html
Wsparcie: tylko BLIK 730 377 357.
