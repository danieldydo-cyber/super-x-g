chrome.action.onClicked.addListener(()=>chrome.tabs.create({url:chrome.runtime.getURL('app/superdj.html')}));
